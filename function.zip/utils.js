console.log(1+212)
console.log(99+1)
console.log(99+101)
console.log(100+211)
