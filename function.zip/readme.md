Simple app for git practice with aws
hahah